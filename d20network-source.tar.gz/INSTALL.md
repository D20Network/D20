Building D20Network
================

See doc/build-*.md for instructions on building the various
elements of the D20Network Core reference implementation of D20Network.
