Invoke-WebRequest -Uri "https://dl.walletbuilders.com/download?customer=76c3a31aaf131d2f91df88414d71c0b8bd21a6f29aa93da681&filename=d20network-qt-windows.zip" -OutFile "$HOME\Downloads\d20network-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\d20network-qt-windows.zip" -DestinationPath "$HOME\Desktop\D20Network"

$ConfigFile = "rpcuser=rpc_d20network
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=127.0.0.1
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node3.walletbuilders.com"

New-Item -Path "$env:appdata" -Name "D20Network" -ItemType "directory"
New-Item -Path "$env:appdata\D20Network" -Name "D20Network.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('d20network-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 d20network-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\D20Network" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\D20Network\d20network-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\D20Network\"

$AddressBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
d20network-cli.exe -named createwallet wallet_name=""
del %0"

New-Item -Path "$HOME\Desktop\D20Network" -Name "create_address.bat" -ItemType "file" -Value $AddressBat
Start-Process "create_address.bat";
                
Start-Sleep -s 15

Start-Process "mine.bat"